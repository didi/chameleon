const state = {
  tabs: [
    {label: '首页'},
    {label: "分类"},
    {label: '识物'},
    {label: '购物车'},
    {label: '个人1'}
  ]
}
export default state
