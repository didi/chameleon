
module.exports = [
  {
      method: ['get', 'post'],
      path: '/api/getHomeImgList',
      controller: function (req, res, next) {
          res.json({
              code: 0,
              data: {
                  bannerImgList: [
                      { imgUrl: 'https://yanxuan.nosdn.127.net/288bf88910aeba6d89689b99bec93133.jpg?imageView&quality=75&thumbnail=750x0'},
                      { imgUrl: 'https://yanxuan.nosdn.127.net/3804d6f02516e59927e07f091c8f1b27.jpg?imageView&quality=75&thumbnail=750x0'},
                      { imgUrl: 'https://yanxuan.nosdn.127.net/ce535663c045b5e877540b0e0be16bb3.jpg?imageView&quality=75&thumbnail=750x0'},
                      { imgUrl: 'https://yanxuan.nosdn.127.net/06af49f2a59b00ad080aeb03fb8d408f.jpg?imageView&quality=75&thumbnail=750x0'},
                      { imgUrl: 'https://yanxuan.nosdn.127.net/7c94908d8e197cc99e942324c5cc526e.jpg?imageView&quality=75&thumbnail=750x0'},
                      { imgUrl: 'https://yanxuan.nosdn.127.net/96cf611743d7b382c11031f29152fa04.jpg?imageView&quality=75&thumbnail=750x0'},
                      { imgUrl: 'https://yanxuan.nosdn.127.net/973e299ac2e80c03acfb5d2d4501231c.jpg?imageView&quality=75&thumbnail=750x0'}
                  ],
                  classifyImgList: [
                      {imgUrl: 'http://yanxuan.nosdn.127.net/9cdedb90a09cf061cfa19f3e21321c73.png', title: '居家'},
                      {imgUrl: 'http://yanxuan.nosdn.127.net/57e39dc404f1ce90b959d76b9abe4314.png', title: '鞋包分配'},
                      {imgUrl: 'http://yanxuan.nosdn.127.net/2b580df265124836dcd96b1c88068127.png', title: '服装'},
                      {imgUrl: 'http://yanxuan.nosdn.127.net/a53fff4d3cf0f4dedd78a8a0f2b129c9.png', title: '电器'},
                      {imgUrl: 'http://yanxuan.nosdn.127.net/6147b31404d5ddf1207a8363605aebf9.png', title: '婴童'},
                      {imgUrl: 'http://yanxuan.nosdn.127.net/8d29af79c24d78a3dcf7d61249702dcf.png', title: '饮食'},
                      {imgUrl: 'http://yanxuan.nosdn.127.net/2b9a25b6ea81655eb431944d3d57185f.png', title: '洗护'},
                      {imgUrl: 'http://yanxuan.nosdn.127.net/293f2341415d70bf7c6460c77fa07f41.png', title: '餐厨'},
                      {imgUrl: 'http://yanxuan.nosdn.127.net/2fbba45f945ee592d5470269d9e61f1c.png', title: '文体'},
                      {imgUrl: 'http://yanxuan.nosdn.127.net/54947b070f8af594dd46069f2d3bdd34.png', title: '特色区'}
                  ],
                  disscountPriceImgUrl: 'https://yanxuan.nosdn.127.net/15468670774810413.gif?imageView&thumbnail=750x0&quality=75',
                  special:{
                      newPerson: 'https://yanxuan.nosdn.127.net/15468671496890421.png',
                      temai: 'https://yanxuan.nosdn.127.net/15468671650860425.png',
                      qingdan: 'https://yanxuan.nosdn.127.net/15468671650860425.png'
                  }
              }
          });
      }
  },
    {
        method: ['get', 'post'],
        path: '/api/listImage',
        controller: function (req, res, next) {
            res.json({
                code: 0,
                data: {
                    topImgUrl: 'http://yanxuan.nosdn.127.net/4972949f269e7295a4f37e99a303553e.jpg?quality=85&thumbnail=750x0&imageView',
                    list:[
                        {
                            imgUrl: 'http://yanxuan.nosdn.127.net/8635c42f2b3a92768b12015c491821b5.png?imageView&quality=65&thumbnail=330x330',
                            des: '400跟纯棉贡缎',
                            name: '60s锦绵贡缎四件套',
                            money: '￥400',
                            tag:['APP特惠']
                        },
                        {
                            imgUrl: 'http://yanxuan.nosdn.127.net/4a00fd1035efe874d70d51dfc04c5cee.png?imageView&quality=65&thumbnail=330x330',
                            des: '少女粉润贡缎',
                            name: '朱莉.粉唐四件套',
                            money: '￥359',
                            tag:['年货节特卖', '满赠']
                        },
                        {
                            imgUrl: 'http://yanxuan.nosdn.127.net/9f3c89c8b98fb06968c67edb12a195cf.png?imageView&quality=65&thumbnail=330x330',
                            des: '少女粉润贡缎',
                            name: '朱莉.粉唐四件套',
                            money: '￥359',
                            tag:[]
                        },
                        {
                            imgUrl: 'http://yanxuan.nosdn.127.net/cc863b46d890633445fb2a1354b01841.png?imageView&quality=65&thumbnail=330x330',
                            des: '入门享受奢华感受',
                            name: '60s锦绵贡缎四件套',
                            money: '￥400',
                            tag:['三石福利价']
                        },
                    ]
                }
            });
        }
    },
    {
        method: ['get', 'post'],
        path: '/api/detailInfo',
        controller: function (req, res, next) {
            res.json({
                code: 0,
                data: {
                    carouselList: [
                        { imgUrl: 'http://yanxuan.nosdn.127.net/5240f52c0f410054fe9c20abc54aa7b9.jpg?imageView&quality=75&thumbnail=750x0'},
                        { imgUrl: 'http://yanxuan.nosdn.127.net/5142255cef97dafd012bb73423eff4d4.png?imageView&quality=75&thumbnail=750x0' },
                        { imgUrl: 'http://yanxuan.nosdn.127.net/0e72c98273b50c0959d34662c2fad4e8.jpg?imageView&quality=75&thumbnail=750x0' },
                        { imgUrl: 'http://yanxuan.nosdn.127.net/44334a3a100aa6fa974c17e352969a6f.jpg?imageView&quality=75&thumbnail=750x0' },
                        { imgUrl: 'http://yanxuan.nosdn.127.net/bf216b5af1dc8cdb5a70e87b8271028c.png?imageView&quality=75&thumbnail=750x0' }
                    ],
                    description: [
                        {
                            imgUrl: 'http://yanxuan.nosdn.127.net/17e5327561f5b9df04f7d000a8c71bb2.jpg',
                            tag1: '贡缎细糯',
                            tag2: '如绸光泽'
                        },
                        {
                            imgUrl: 'http://yanxuan.nosdn.127.net/459cfd6a33991746fc2cf452642c7c68.jpg',
                            tag1: '高支纯棉',
                            tag2: '新贵臻密'
                        },
                        {
                            imgUrl: 'http://yanxuan.nosdn.127.net/964045a4796d70488adfef26a3093e35.jpg',
                            tag1: '同色边框',
                            tag2: '精致恰好'
                        }

                    ],
                    money: '￥469',
                    tag: 'App特惠￥455.00'
                }
            });
        }
    }
]
